Get started
===============

To get started simply choose your language interface and follow the easy installation instructions below:

.. toctree::
   :maxdepth: 1
   :glob:

   sources.rst
   CC++.rst
   python.rst
   julia.rst
   matlab.rst
   r.rst
   cutest.rst
   linear_system_solvers.rst
